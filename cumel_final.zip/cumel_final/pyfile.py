import subprocess

# Initial hex value
hex_decrement = "3fffffffff00000000000000000000000"
hex_decrement = "0000000000000000000000000003f0000"

# Stop condition
# stop_hex_value = "200000000000000000000000000000000"
stop_hex_value = "000000000000000000000000000200000"

# Loop
while hex_decrement >= stop_hex_value:
    # Convert hex to decimal
    decimal_value = int(hex_decrement, 16)

    # Run the command
    command = f"./mel 02ebe98eaa601c6639d5b203dfc2bd93a8344fc66a52423e18dccee72802dd4c2e - {decimal_value}"
    command = f"./mel 0228CBCC1F0FF1B2D1F77A606F6D57A0C41E3C8E38D052F4536B2EE7E19848F4AF - {decimal_value}"
    result = subprocess.run(command, shell=True, capture_output=True, text=True)

    # Save the result to a file
    with open('./the.txt', 'a') as file:
        file.write(f"Hex: {hex_decrement}\nDecimal: {decimal_value}\nResult: {result.stdout.strip()}\n{'='*30}\n")

    # Print the result to the console
    print(f"Hex: {hex_decrement}\nDecimal: {decimal_value}\nResult: {result.stdout.strip()}\n{'='*30}\n")

    # Decrement hex value
    # decimal_decrement = int("10000000000000000000000", 16)
    decimal_decrement = int("00000000000000000010000", 16)
    
    decimal_value -= decimal_decrement
    hex_decrement = hex(decimal_value)[2:]
    
# Note: This script runs until the hex value is less than the stop_hex_value.

