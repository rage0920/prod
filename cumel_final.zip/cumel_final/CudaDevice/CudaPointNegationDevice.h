#ifndef _CUDA_POINT_NEGATION_DEVICE
#define _CUDA_POINT_NEGATION_DEVICE

#include "../PointNegator/PointNegationDevice.h"
#include <vector>
#include <fstream>
#include <iterator>
#include <cuda_runtime.h>
#include "../Secp256k1/secp256k1.h"






#endif